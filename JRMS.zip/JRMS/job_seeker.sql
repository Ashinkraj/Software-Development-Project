CREATE TABLE job_postings (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  CompanyName TEXT,
  job_title TEXT,
  job_description TEXT,
  company_name TEXT,
  job_requirements TEXT,
  employment_type TEXT,
  location TEXT,
  compensation TEXT,
  application_deadline TEXT,
  contact_info TEXT
);
ALTER TABLE job_postings ADD COLUMN job_field TEXT DEFAULT 'Computer science';
UPDATE job_postings SET job_field = 'Civil' WHERE CompanyName = 'Demo Company';
SELECT * FROM job_postings;

DELETE FROM job_postings WHERE job_title = 'Test Engineer';
CREATE TABLE login (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  Username TEXT NOT NULL,
  email TEXT NOT NULL,
  Password TEXT NOT NULL
);
    DELETE FROM user_details WHERE id = 3;
select * from login
UPDATE login SET Ac_type = 'Recruiter account' WHERE Username = 'jolly';
ALTER TABLE login ADD COLUMN Ac_type TEXT DEFAULT 'login user';
ALTER TABLE user_details ADD COLUMN Job_Applications TEXT DEFAULT 'Not applied yet';
select * from user_details;
  DELETE FROM user_details WHERE id =7;
SELECT education_1, education_2, Experience_1, Experience_2, Bio FROM profile WHERE Username='jolly ';
CREATE TABLE user_details
(
id INTEGER PRIMARY KEY AUTOINCREMENT,
Username TEXT NOT NULL,
profile_photo TEXT,
education_1 TEXT NOT NULL,
education_2 TEXT NOT NULL,
Experience_1 TEXT NOT NULL,
Experience_2 TEXT NOT NULL,
Bio TEXT NOT NULL
);
ALTER TABLE user_details ADD COLUMN email TEXT;
UPDATE user_details SET email = 'johndeo@example.com' WHERE Username = 'avi';
select * from user_details
 CREATE TABLE job_applications (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        username TEXT,
        full_name TEXT,
        email TEXT,
        phone TEXT,
        resume BLOB,
        cover_letter TEXT,
        references1 TEXT,
        portfolio TEXT,
        certifications TEXT
    );
    Select * from job_applications

    DELETE FROM job_applications WHERE id =12;